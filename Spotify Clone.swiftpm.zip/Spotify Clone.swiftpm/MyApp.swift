import SwiftUI

@main
struct Spotify_UI_CloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
